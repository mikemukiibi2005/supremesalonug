import{t,a as e}from"../chunks/Cbh3XB3d.js";import"../chunks/CY5slFgH.js";var p=t('<a href="/demo/lucia">lucia</a>');function i(a){var o=p();e(a,o)}export{i as component};
