import{l as o,d as r}from"../chunks/SE0PEW9U.js";export{o as load_css,r as start};
