import { f as escape_html, e as pop, p as push } from "../../../../chunks/index2.js";
import "../../../../chunks/client.js";
function _page($$payload, $$props) {
  push();
  let { data } = $$props;
  $$payload.out += `<h1>Hi, ${escape_html(data.user.username)}!</h1> <p>Your user ID is ${escape_html(data.user.id)}.</p> <form method="post" action="?/logout"><button>Sign out</button></form>`;
  pop();
}
export {
  _page as default
};
