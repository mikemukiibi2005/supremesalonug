import { i as invalidateSession, d as deleteSessionTokenCookie } from "../../../../chunks/auth.js";
import { r as redirect, f as fail } from "../../../../chunks/index.js";
const load = async (event) => {
  if (!event.locals.user) {
    return redirect(302, "/demo/lucia/login");
  }
  return { user: event.locals.user };
};
const actions = {
  logout: async (event) => {
    if (!event.locals.session) {
      return fail(401);
    }
    await invalidateSession(event.locals.session.id);
    deleteSessionTokenCookie(event);
    return redirect(302, "/demo/lucia/login");
  }
};
export {
  actions,
  load
};
