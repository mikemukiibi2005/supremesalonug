import { f as escape_html, e as pop, p as push } from "../../../../../chunks/index2.js";
import "../../../../../chunks/client.js";
function _page($$payload, $$props) {
  push();
  let { form } = $$props;
  $$payload.out += `<h1>Login/Register</h1> <form method="post" action="?/login"><label>Username <input name="username"></label> <label>Password <input type="password" name="password"></label> <button>Login</button> <button formaction="?/register">Register</button></form> <p style="color: red">${escape_html(form?.message ?? "")}</p>`;
  pop();
}
export {
  _page as default
};
