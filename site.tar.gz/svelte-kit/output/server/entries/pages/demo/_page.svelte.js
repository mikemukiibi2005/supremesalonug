function _page($$payload) {
  $$payload.out += `<a href="/demo/lucia">lucia</a>`;
}
export {
  _page as default
};
