import * as server from '../entries/pages/demo/lucia/login/_page.server.ts.js';

export const index = 5;
let component_cache;
export const component = async () => component_cache ??= (await import('../entries/pages/demo/lucia/login/_page.svelte.js')).default;
export { server };
export const server_id = "src/routes/demo/lucia/login/+page.server.ts";
export const imports = ["_app/immutable/nodes/5.DmfJL9bV.js","_app/immutable/chunks/Cbh3XB3d.js","_app/immutable/chunks/CRFVu_O7.js","_app/immutable/chunks/j66TGGhz.js","_app/immutable/chunks/m8xk5RfJ.js","_app/immutable/chunks/SE0PEW9U.js","_app/immutable/chunks/BfCYhiwC.js"];
export const stylesheets = [];
export const fonts = [];
