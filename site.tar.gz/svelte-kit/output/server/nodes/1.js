

export const index = 1;
let component_cache;
export const component = async () => component_cache ??= (await import('../entries/fallbacks/error.svelte.js')).default;
export const imports = ["_app/immutable/nodes/1.tnem83Vd.js","_app/immutable/chunks/Cbh3XB3d.js","_app/immutable/chunks/CRFVu_O7.js","_app/immutable/chunks/CY5slFgH.js","_app/immutable/chunks/j66TGGhz.js","_app/immutable/chunks/DE2zy0SH.js","_app/immutable/chunks/SE0PEW9U.js","_app/immutable/chunks/BfCYhiwC.js"];
export const stylesheets = [];
export const fonts = [];
