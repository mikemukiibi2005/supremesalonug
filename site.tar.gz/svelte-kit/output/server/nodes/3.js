

export const index = 3;
let component_cache;
export const component = async () => component_cache ??= (await import('../entries/pages/demo/_page.svelte.js')).default;
export const imports = ["_app/immutable/nodes/3.9ZQfjPJH.js","_app/immutable/chunks/Cbh3XB3d.js","_app/immutable/chunks/CRFVu_O7.js","_app/immutable/chunks/CY5slFgH.js"];
export const stylesheets = [];
export const fonts = [];
