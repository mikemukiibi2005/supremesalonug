

export const index = 2;
let component_cache;
export const component = async () => component_cache ??= (await import('../entries/pages/_page.svelte.js')).default;
export const imports = ["_app/immutable/nodes/2.DpppxMMS.js","_app/immutable/chunks/Cbh3XB3d.js","_app/immutable/chunks/CRFVu_O7.js","_app/immutable/chunks/CY5slFgH.js","_app/immutable/chunks/j66TGGhz.js","_app/immutable/chunks/Dw6kdkNN.js","_app/immutable/chunks/DE2zy0SH.js","_app/immutable/chunks/BmXuwEB-.js"];
export const stylesheets = [];
export const fonts = [];
